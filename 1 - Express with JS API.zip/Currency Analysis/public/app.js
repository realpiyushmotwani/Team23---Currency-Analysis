// app.js
document.addEventListener("DOMContentLoaded", async function () {
    // Populate country dropdowns
    try {
      const response = await fetch('/api/countries');
      const countries = await response.json();
      populateDropdown("country1", countries);
      populateDropdown("country2", countries);
    } catch (error) {
      console.error('Error fetching countries:', error);
      alert('Error fetching countries. Please try again.');
    }
  });
  
  function populateDropdown(elementId, values) {
    const dropdown = document.getElementById(elementId);
    values.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.text = value;
      dropdown.appendChild(option);
    });
  }
  
  async function generateAnalysis() {
    const country1 = document.getElementById("country1").value;
    const country2 = document.getElementById("country2").value;
    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;
    const year = startDate.split('-')[0]; // Assuming the year is part of the start date
  
    try {
      const response = await fetch(`/api/data/${year}`);
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
  
      // Filter data based on start and end dates
      const filteredData = data.filter(entry => entry.Date >= startDate && entry.Date <= endDate);
  
      // Extract data for the selected countries
      const country1Data = filteredData.map(entry => entry[country1]);
      const country2Data = filteredData.map(entry => entry[country2]);
      const dates = filteredData.map(entry => entry.Date);
  
      // Create a line chart
      const ctx = document.getElementById('lineChart').getContext('2d');
      const lineChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: dates,
          datasets: [
            {
              label: country1,
              data: country1Data,
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 3,
              fill: false,
            },
            {
              label: country2,
              data: country2Data,
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 3,
              fill: false,
            },
          ],
        },
        options: {
          scales: {
            x: {
              type: 'linear',
              position: 'bottom',
            },
          },
        },
      });
  
      alert(`Generating analysis for ${country1} and ${country2} from ${startDate} to ${endDate}`);
    } catch (error) {
      console.error('Error fetching data:', error.message);
      alert('Error fetching data. Please try again.');
    }
  }
  

  
  
  
  
  
  
  