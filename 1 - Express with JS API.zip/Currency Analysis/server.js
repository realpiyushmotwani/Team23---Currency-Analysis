const express = require('express');
const path = require('path');
const fs = require('fs');
const csv = require('csv-parser');

const app = express();
const port = 3000;

app.use(express.static(path.join(__dirname, 'public')));

// Endpoint to get the list of countries
app.get('/api/countries', (req, res) => {
    const filePath = path.join(__dirname, 'data', 'Exchange_Rate_Report_2012.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            const countries = Object.keys(row).slice(1); // Exclude the 'Date' column
            res.json(countries);
        })
        .on('end', () => {
            // CSV file has been fully read
        })
        .on('error', (error) => {
            res.status(500).json({ error: 'Error reading CSV file' });
        });
});

// Endpoint to get data for a specific year
app.get('/api/data/:year', (req, res) => {
    const year = req.params.year;
    const filePath = path.join(__dirname, 'data', `Exchange_Rate_Report_${year}.csv`);

    const data = [];

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            data.push(row);
        })
        .on('end', () => {
            res.json(data);
        })
        .on('error', (error) => {
            res.status(500).json({ error: 'Error reading CSV file' });
        });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
