import os
import matplotlib.pyplot as plt
import pandas as pd
import sys

def generate_plot(country1, country2, start_date, end_date, year):
    # Dynamically construct the CSV file path based on the provided year
    csv_file_path = f'/data/Exchange_Rate_Report_{year}.csv'

    # Check if the file exists
    if not os.path.exists(csv_file_path):
        print(f"Error: CSV file for the year {year} not found.")
        sys.exit(1)

    # Load CSV file into a DataFrame
    df = pd.read_csv(csv_file_path)

    # Convert the 'Date' column to datetime format
    df['Date'] = pd.to_datetime(df['Date'], format='%d-%b-%y')

    # Filter data based on selected countries and dates
    filtered_data = df.loc[(df['Date'] >= start_date) & (df['Date'] <= end_date), ['Date', country1, country2]]

    # Create a date range for all dates in the specified range
    all_dates = pd.date_range(start=start_date, end=end_date, freq='D')

    # Merge with the complete date range to include all dates
    filtered_data = pd.merge(pd.DataFrame(all_dates, columns=['Date']), filtered_data, how='left', on='Date')

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(filtered_data['Date'], filtered_data[country1], label=country1)
    plt.plot(filtered_data['Date'], filtered_data[country2], label=country2)
    plt.xlabel('Date')
    plt.ylabel('Currency Value')
    plt.title(f'Currency Comparison between {country1} and {country2} in {year}')
    plt.legend()
    plt.grid(True)

    # Save the plot as an image in the public folder
    image_path = f'./public/plots/line_chart_{start_date}_{end_date}.png'
plt.savefig(image_path)

print(f"Image saved at: {image_path}")

if __name__ == "__main__":
    if len(sys.argv) != 6:
        print("Usage: python generate_plot.py <country1> <country2> <start_date> <end_date> <year>")
        sys.exit(1)

    country1, country2, start_date, end_date, year = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
    generate_plot(country1, country2, start_date, end_date, year)
