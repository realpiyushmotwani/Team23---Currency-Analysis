document.addEventListener("DOMContentLoaded", async function () {
    // Populate country dropdowns
    try {
        const response = await fetch('/api/countries');
        const countries = await response.json();
        populateDropdown("country1", countries);
        populateDropdown("country2", countries);
    } catch (error) {
        console.error('Error fetching countries:', error);
        alert('Error fetching countries. Please try again.');
    }
});

function populateDropdown(elementId, values) {
    const dropdown = document.getElementById(elementId);
    values.forEach(value => {
        const option = document.createElement("option");
        option.value = value;
        option.text = value;
        dropdown.appendChild(option);
    });
}

async function generateAnalysis() {
    const country1 = document.getElementById("country1").value;
    const country2 = document.getElementById("country2").value;
    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;
    const year = startDate.split('-')[0]; // Assuming the year is part of the start date

    try {
        // Call the endpoint to generate the plot
        const response = await fetch('/api/generatePlot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                country1,
                country2,
                startDate,
                endDate,
            }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Extract the image URL from the response
        const imageURL = await response.text();

        // Create an image element and set its attributes
        const imageElement = document.createElement('img');
        imageElement.src = imageURL;
        imageElement.alt = 'Currency Analysis Plot';

        // Append the image element to the container
        const container = document.querySelector('.container');
        container.appendChild(imageElement);

        alert(`Generating analysis for ${country1} and ${country2} from ${startDate} to ${endDate}`);
    } catch (error) {
        console.error('Error fetching data:', error.message);
        alert('Error fetching data. Please try again.');
    }
}
