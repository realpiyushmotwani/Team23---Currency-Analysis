import pandas as pd

# Specify the path to the merged CSV file
merged_csv_path = r'D:\OneDrive\Desktop\hackathon\public\csv\merging2_file.csv'

# Read the merged CSV file into a DataFrame
merged_data = pd.read_csv(merged_csv_path)

# Display basic information about the DataFrame
print("Basic Information about the Merged Data:")
print(merged_data.info())

# Display summary statistics for numeric columns
print("\nSummary Statistics for Numeric Columns:")
print(merged_data.describe())

# Display the first few rows of the DataFrame
print("\nFirst Few Rows of the Merged Data:")
print(merged_data.head())

# Check for missing values
print("\nMissing Values:")
print(merged_data.isnull().sum())
