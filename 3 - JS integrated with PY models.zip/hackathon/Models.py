# Step 1: Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Step 2: Load your dataset
# Replace 'your_dataset.csv' with the actual filename
df = pd.read_csv('D:\OneDrive\Desktop\hackathon\path_to_save_preprocessed_file.csv')

# # Step 3: Split the dataset into features (X) and labels (y)
# X = dataset.drop('target_column', axis=1)  # Replace 'target_column' with the actual target column name
# y = dataset['target_column']

# # Step 4: Split the dataset into training and testing sets
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Step 5: Choose a model and train it
# model = RandomForestClassifier(n_estimators=100, random_state=42)
# model.fit(X_train, y_train)

# # Step 6: Make predictions on the test set
# y_pred = model.predict(X_test)

# # Step 7: Evaluate the model
# accuracy = accuracy_score(y_test, y_pred)
# print(f"Accuracy: {accuracy:.2f}")

# # Additional evaluation metrics
# print("Classification Report:\n", classification_report(y_test, y_pred))


print(df.columns)