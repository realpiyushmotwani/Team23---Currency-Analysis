import mysql.connector
from tabulate import tabulate

# MySQL connection details
username = 'root'
password = 'root'
host = 'localhost'
database_name = 'exchange'

# Establishing connection to MySQL
conn = mysql.connector.connect(
    user=username,
    password=password,
    host=host,
    database=database_name
)

# Creating a cursor object using the cursor() method
cursor = conn.cursor()

# Executing MySQL query
query = "SELECT * FROM exchange_table LIMIT 10"  # Replace with your table name and desired query
cursor.execute(query)

# Fetching all rows from the query result
rows = cursor.fetchall()

# Getting column names
column_names = [desc[0] for desc in cursor.description]

# Closing the cursor and connection
cursor.close()
conn.close()

# Displaying fetched data in a table format
print(tabulate(rows, headers=column_names, tablefmt="grid"))
