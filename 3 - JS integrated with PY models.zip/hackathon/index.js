// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql');

// Create an Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(bodyParser.json());

// Create a MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'exchange',
    connectionLimit: 10
});

// Define a route for the root path
app.get('/', (req, res) => {
    // Assuming your HTML file is named 'dashboard.html' and is in the 'public' directory
    res.sendFile(path.join(__dirname, 'templates', 'dashboard.html'));
});

// Fetch column names from a specified table
function fetchColumnNames(tableName, callback) {
    const query = `SHOW COLUMNS FROM ${tableName}`;
    pool.query(query, (error, results) => {
        if (error) {
            console.error('Error fetching column names:', error);
            callback(error, null);
        } else {
            const columnNames = results.map(column => column.Field);
            callback(null, columnNames);
        }
    });
}

// Update the /fetchData route
app.post('/fetchData', async (req, res) => {
    try {
        console.log('Received request body:', req.body);

        const { currency, duration } = req.body;

        // Validate currency
        console.log('Validating currency:', currency);
        
        const validCurrencies = [
            'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD', 'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL',
            'BSD', 'BTN', 'BWP', 'BYN', 'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF', 'DKK', 'DOP', 'DZD', 'EGP', 'ERN',
            'ETB', 'EUR', 'FJD', 'FKP', 'FOK', 'GBP', 'GEL', 'GGP', 'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HRK', 'HTG', 'HUF', 'IDR', 'ILS',
            'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD', 'JPY', 'KES', 'KGS', 'KHR', 'KID', 'KIN', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP', 'LKR',
            'LRD', 'LSL', 'LYD', 'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN', 'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK',
            'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK', 'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR', 'SDG', 'SEK', 'SGD',
            'SHP', 'SLL', 'SOS', 'SRD', 'SSP', 'STN', 'SYP', 'SZL', 'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY', 'TTD', 'TVD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD',
            'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XDR', 'XOF', 'XPF', 'YER', 'ZAR', 'ZMW', 'ZWD'
        ];
        
        if (!validCurrencies.includes(currency)) {
            console.log('Invalid currency provided:', currency);
            return res.status(400).json({ error: 'Invalid currency provided' });
        }

        // Check if the provided currency is a valid column in the table
        const columnNames = await fetchColumnNames('exchange_table');
        console.log('Column Names:', columnNames);

        if (!columnNames || !columnNames.includes(currency)) {
            console.log('Invalid currency column in the database:', currency);
            return res.status(400).json({ error: 'Invalid currency column in the database' });
        }

        // ... rest of your code ...

    } catch (error) {
        console.error('Unexpected error in /fetchData:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Function to calculate the start date based on the user's duration selection
function calculateStartDate(duration) {
    const currentDate = new Date();
    switch (duration) {
        case 'weekly':
            currentDate.setDate(currentDate.getDate() - 7);
            break;
        case 'monthly':
            currentDate.setMonth(currentDate.getMonth() - 1);
            break;
        case 'quarterly':
            currentDate.setMonth(currentDate.getMonth() - 3);
            break;
        case 'annual':
            currentDate.setFullYear(currentDate.getFullYear() - 1);
            break;
        default:
            break;
    }
    return currentDate.toISOString().split('T')[0]; // Format as YYYY-MM-DD
}

// Function to get the date on which the rate was highest
function getHighestRateDate(data) {
    const maxRateIndex = data.findIndex(entry => entry.Rate === Math.max(...data.map(e => e.Rate)));
    return data[maxRateIndex].Date;
}

// Function to get the date on which the rate was lowest
function getLowestRateDate(data) {
    const minRateIndex = data.findIndex(entry => entry.Rate === Math.min(...data.map(e => e.Rate)));
    return data[minRateIndex].Date;
}

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
