import os
import pandas as pd
import glob

# Specify the path to the directory containing your CSV files
csv_directory = r'D:\OneDrive\Desktop\hackathon\public\csv'

# Change to the specified directory
os.chdir(csv_directory)

# Get a list of all CSV files in the directory
csv_files = glob.glob('Exchange_Rate_Report_*.csv')

# Initialize an empty list to store DataFrames
dataframes = []

# Iterate through each CSV file and read it into a DataFrame
for file in csv_files:
    df = pd.read_csv(file)
    df['Date'] = pd.to_datetime(df['Date'].str.strip(), format='%d-%b-%y', errors='coerce')
    
    # Add a suffix to the columns based on the source file
    suffix = os.path.splitext(os.path.basename(file))[0]
    df = df.add_suffix(f'_{suffix}')
    
    dataframes.append(df)

# Concatenate all DataFrames into a single DataFrame
merged_data = pd.concat(dataframes, axis=1)

# Find the first 'Date' column in the DataFrame
date_column = next(col for col in merged_data.columns if 'Date' in col)

# Sort the merged DataFrame based on the 'Date' column
merged_data = merged_data.sort_values(by=date_column)

# Display the merged DataFrame
print(merged_data)

# Specify the path to save the merged data
output_path = r'D:\OneDrive\Desktop\hackathon\public\csv\save_preprocessed_file.csv'

# Save the merged DataFrame to a new CSV file
merged_data.to_csv(output_path, index=False)
