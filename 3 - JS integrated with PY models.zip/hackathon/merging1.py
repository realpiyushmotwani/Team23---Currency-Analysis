import os
import pandas as pd

# Specify the path to the directory containing your CSV files
original_csv_directory = r'D:\OneDrive\Desktop\hackathon\public\csv'

# Specify the path to the merged CSV file
merged_csv_path = r'D:\OneDrive\Desktop\hackathon\public\csv\save_preprocessed_file.csv'

# Specify the path to save the advanced aligned data
output_path = r'D:\OneDrive\Desktop\hackathon\public\csv\advanced_aligned_data.csv'

# Get a list of all original CSV files in the directory
original_csv_files = [file for file in os.listdir(original_csv_directory) if file.startswith('Exchange_Rate_Report_')]

# Read the merged CSV file into a DataFrame
merged_data = pd.read_csv(merged_csv_path)

# Find the common date column dynamically
common_date_column = next(col for col in merged_data.columns if 'Date' in col)

# Create an empty DataFrame to store the advanced aligned data
advanced_aligned_data = pd.DataFrame({common_date_column: pd.to_datetime(merged_data[common_date_column], format='%Y-%m-%d')})

# Iterate through each original CSV file and perform advanced alignment
for original_file in original_csv_files:
    # Read the original CSV file into a DataFrame
    original_data = pd.read_csv(os.path.join(original_csv_directory, original_file))
    
    # Convert the 'Date' column to datetime format
    original_data['Date'] = pd.to_datetime(original_data['Date'], format='%Y-%m-%d')

    # Merge based on the continuous date range
    advanced_aligned_data = pd.merge(advanced_aligned_data, original_data, on='Date', how='left', suffixes=('', f'_{os.path.splitext(original_file)[0]}'))

# Merge with the merged dataset to include additional columns
advanced_aligned_data = pd.merge(advanced_aligned_data, merged_data, on='Date', how='left', suffixes=('_original', '_merged'))

# Save the advanced aligned DataFrame to a new CSV file
advanced_aligned_data.to_csv(output_path, index=False)

print(f"Advanced aligned data saved to {output_path}")
