// Simulated rates for each currency code over a period (for demonstration purposes)
const simulatedData = {
    'USD': [1.0, 1.2, 1.15, 1.18, 1.25],  // Simulated rates for USD for 5 periods
    'EUR': [0.85, 0.82, 0.88, 0.9, 0.87], // Simulated rates for EUR for 5 periods
    'GBP': [0.72, 0.69, 0.71, 0.75, 0.78], // Simulated rates for GBP for 5 periods
    // Add simulated rates for other currency codes as needed...
};

// Function to fetch simulated data for a given currency code
function fetchDataForCurrency(currencyCode) {
    return new Promise((resolve, reject) => {
        // Simulate fetching data using setTimeout to mimic an asynchronous operation
        setTimeout(() => {
            if (simulatedData.hasOwnProperty(currencyCode)) {
                // Simulating data for dates and rates (just as an example)
                const dates = ['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05'];
                const rates = simulatedData[currencyCode];
                resolve({ dates, rates });
            } else {
                reject(new Error('Currency code not found'));
            }
        }, 1000); // Simulate a delay of 1 second (1000ms) for fetching data
    });
}

function generateChart(data) {
    const ctx = document.getElementById('exchange-rate-chart').getContext('2d');
    
    const dates = data.dates;
    const rates = data.rates;

    new Chart(ctx, {
        type: 'line', // Change the chart type to line for rate trends
        data: {
            labels: dates,
            datasets: [{
                label: 'Exchange Rate Trend',
                data: rates,
                fill: false,
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });
}

// Example of how to use the fetchDataForCurrency function
// Replace 'USD' with the desired currency code
fetchDataForCurrency('USD')
    .then(data => {
        // Generate chart when data is available
        generateChart(data);
    })
    .catch(error => {
        console.error('Error fetching data:', error);
    });
