import pandas as pd
from sqlalchemy import create_engine

# Read the CSV file
file_path = 'D:\OneDrive\Desktop\hackathon\path_to_save_preprocessed_file.csv'  # Replace with the path to your CSV file
df = pd.read_csv(file_path)

# Clean column names
df.columns = df.columns.str.strip().str.replace(r'[^\w\s]', '', regex=True)

# Define MySQL connection parameters
username = 'root'
password = 'root'
host = 'localhost'
database_name = 'exchange'

# Create an SQLAlchemy engine
engine = create_engine(f"mysql+mysqlconnector://{username}:{password}@{host}/{database_name}")

# Define the table name
table_name = 'exchange_table'

# Load data into MySQL
df.to_sql(name=table_name, con=engine, if_exists='replace', index=False)

print(f"Data from '{file_path}' loaded into table '{table_name}' in database '{database_name}'.")
